﻿namespace SpaceStation.Models.Astronauts
{
    public class Biologist : Astronaut
    {
        /// <inheritdoc />
        public Biologist(string name) : base(name, 70)
        {
        }
    }
}
