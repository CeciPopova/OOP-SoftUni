﻿using AquaShop.Models.Decorations.Contracts;
using AquaShop.Models.Fish.Contracts;
using System;
using System.Collections.Generic;

namespace AquaShop.Models.Aquariums
{
    public class FreshwaterAquarium : Aquarium
    {

        public FreshwaterAquarium(string name, int capacity) : base(name, 50)
        {

        }

      
    }
}
