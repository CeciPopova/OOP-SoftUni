﻿namespace AquaShop.Models.Decorations
{
    public class Ornament : Decoration
    {
        public Ornament() : base(1, 5)
        {
        }
    }
}
