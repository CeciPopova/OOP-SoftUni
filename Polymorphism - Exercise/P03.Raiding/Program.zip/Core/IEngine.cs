﻿namespace Raiding.Core
{
    public interface IEngine
    {
        void Start();
    }
}
