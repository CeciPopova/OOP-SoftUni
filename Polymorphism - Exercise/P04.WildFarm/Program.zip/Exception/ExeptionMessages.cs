﻿namespace WildFarm.Exception
{
    public static class ExeptionMessages
    {
        public const string FoodNotPreffered = "{0} does not eat {1}!";
    }
}
