﻿namespace BorderControl
{
    public interface IBuyer
    {
        void BuyFood();
        public int Food { get; }
    }
}
