﻿namespace BorderControl
{
    public interface ICelebratable
    {
        string Birthdate { get; set; }
    }
}
