﻿namespace BorderControl
{
    public interface IIdentificable
    {
        string Id { get; set; }
    }
}
