﻿namespace Telephony.Models.Interfaces
{
    public interface IBrowseable
    {
        string BrowseURL(string url);
    }
}
