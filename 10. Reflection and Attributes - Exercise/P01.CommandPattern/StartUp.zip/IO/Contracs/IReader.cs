﻿namespace CommandPattern.IO.Contracs
{
    public interface IReader
    {
        string ReadLine();
    }
}
